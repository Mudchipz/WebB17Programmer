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
git config --global user.email "muhammadfirgi131@gmail.com"
  git config --global user.name "Mudchipz"

git add .
git commit -m "nambah data"
git push

alamat
/c/Users/pc/Documents/webprogramming hacktive-b17/materi